#include <stdio.h>

int une_globale = 42;

int main(void)
{
	printf("La globale vaut: %d\n", une_globale);
	return (0);
}
