#include <stdio.h>

int main(void)
{
	puts("Test facile");
	return (0);
}
